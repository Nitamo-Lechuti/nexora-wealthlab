# Nexora WealthLab — Website Starter

A responsive static website prototype for a financial education platform. Built with HTML, CSS, and vanilla JavaScript.

## What's included
- `index.html` — homepage, learning hub, tool cards, FutureSim, book feature, footer
- `styles.css` — responsive dark charcoal / emerald / electric-blue visual system
- `script.js` — mobile navigation, budget snapshot calculator, compound-growth illustration, and financial shock simulator

## Run locally
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.

No build step or API key is required for this prototype.

## Important
- The book section is a placeholder until the final book edition has been reviewed and approved for distribution.
- The tools are educational prototypes and do not provide personalised financial, tax, investment, or legal advice.
- No form or database is connected yet. The calculators run in the browser.
- Before publishing, add a real contact method, privacy notice, terms, accessibility review, and any required local regulatory disclosures.
- If using external fonts, an internet connection is needed; system fallbacks are included.
