const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const fmt = value => new Intl.NumberFormat("en-BW", {maximumFractionDigits: 2}).format(Math.round(value * 100) / 100);
$("#year").textContent = new Date().getFullYear();

const nav = $(".nav");
$(".menu-toggle").addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  $(".menu-toggle").setAttribute("aria-expanded", String(isOpen));
});
$$(".nav a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  $(".menu-toggle").setAttribute("aria-expanded", "false");
}));

function updateShock() {
  const income = Math.max(0, Number($("#monthly-income").value) || 0);
  const expenses = Math.max(0, Number($("#monthly-expenses").value) || 0);
  const shock = Math.max(0, Number($("#income-shock").value) || 0);
  const unexpected = Math.max(0, Number($("#unexpected-cost").value) || 0);
  const position = income * (1 - shock / 100) - expenses - unexpected;
  $("#shock-value").textContent = `${shock}%`;
  const result = $("#shock-result");
  result.textContent = `${position < 0 ? "−" : "+"}P ${fmt(Math.abs(position))}`;
  result.classList.toggle("negative", position < 0);
  $("#result-guidance").textContent = position < 0
    ? "This scenario creates an estimated shortfall. Consider which essential costs must be protected first, whether any non-essential costs can be paused, and what legitimate support may be available."
    : "In this illustrative scenario, income still covers the listed expenses and one-off cost. Consider whether the remaining amount is enough for other obligations and irregular costs.";
}
["monthly-income","monthly-expenses","income-shock","unexpected-cost"].forEach(id => $(`#${id}`).addEventListener("input", updateShock));
$("#reset-simulator").addEventListener("click", () => {
  $("#monthly-income").value = 3500;
  $("#monthly-expenses").value = 2800;
  $("#income-shock").value = 20;
  $("#unexpected-cost").value = 500;
  updateShock();
});
updateShock();

const dialog = $("#tool-dialog");
const dialogContent = $("#dialog-content");
const closeDialog = () => dialog.close();
$(".close-dialog").addEventListener("click", closeDialog);
dialog.addEventListener("click", event => { if (event.target === dialog) closeDialog(); });

const toolTemplates = {
  budget: {
    title: "Budget snapshot",
    html: `<div class="dialog-fields">
      <label>Monthly take-home income<input id="budget-income" type="number" min="0" value="3500"></label>
      <label>Essential expenses<input id="budget-essentials" type="number" min="0" value="2200"></label>
      <label>Debt repayments<input id="budget-debt" type="number" min="0" value="400"></label>
      <label>Other spending and planned costs<input id="budget-other" type="number" min="0" value="500"></label>
    </div><div class="dialog-result"><small>ESTIMATED MONTHLY BALANCE</small><strong id="budget-result">P 400</strong></div><p class="dialog-note">An estimate, not a judgement. Include irregular costs where possible. A positive balance does not automatically mean all obligations have been covered.</p>`,
    init() {
      const ids = ["budget-income","budget-essentials","budget-debt","budget-other"];
      const calc = () => {
        const [income, essentials, debt, other] = ids.map(id => Math.max(0, Number($(`#${id}`).value) || 0));
        const balance = income - essentials - debt - other;
        $("#budget-result").textContent = `${balance < 0 ? "−" : ""}P ${fmt(Math.abs(balance))}`;
      };
      ids.forEach(id => $(`#${id}`).addEventListener("input", calc));
      calc();
    }
  },
  compound: {
    title: "Compound growth explorer",
    html: `<div class="dialog-fields">
      <label>Starting amount (P)<input id="growth-start" type="number" min="0" value="500"></label>
      <label>Monthly contribution (P)<input id="growth-monthly" type="number" min="0" value="200"></label>
      <label>Assumed annual return (%)<input id="growth-rate" type="number" min="-99" max="100" step="0.5" value="5"></label>
      <label>Years invested<input id="growth-years" type="number" min="1" max="60" value="10"></label>
    </div><div class="dialog-result"><small>ILLUSTRATIVE FUTURE VALUE</small><strong id="growth-result">P 31,000</strong></div><p class="dialog-note">This is a mathematical illustration with a constant assumed rate and monthly compounding. Real investment returns vary, may be negative, and may be affected by fees, taxes, and inflation. This is not a forecast.</p>`,
    init() {
      const ids = ["growth-start","growth-monthly","growth-rate","growth-years"];
      const calc = () => {
        const start = Math.max(0, Number($("#growth-start").value) || 0);
        const monthly = Math.max(0, Number($("#growth-monthly").value) || 0);
        const annual = (Number($("#growth-rate").value) || 0) / 100;
        const years = Math.max(1, Math.min(60, Number($("#growth-years").value) || 1));
        const n = years * 12;
        const r = Math.pow(1 + annual, 1/12) - 1;
        let total = start;
        for (let i=0; i<n; i++) total = total * (1 + r) + monthly;
        $("#growth-result").textContent = `P ${fmt(total)}`;
      };
      ids.forEach(id => $(`#${id}`).addEventListener("input", calc));
      calc();
    }
  },
  simulator: {
    title: "FutureSim shock test",
    html: `<p style="color:#a6b4c0;font-size:13px">Use the interactive simulator on the page to model an income reduction and an unexpected cost. Your inputs stay in this page during this session.</p><button class="button button-primary" id="go-simulator">Open FutureSim <span>↗</span></button>`,
    init() {
      $("#go-simulator").addEventListener("click", () => {
        closeDialog();
        $("#simulator").scrollIntoView({behavior:"smooth"});
        $("#monthly-income").focus({preventScroll:true});
      });
    }
  }
};
$$("[data-open]").forEach(button => button.addEventListener("click", () => {
  const tool = toolTemplates[button.dataset.open];
  $("#dialog-title").textContent = tool.title;
  dialogContent.innerHTML = tool.html;
  dialog.showModal();
  tool.init();
}));
$$('a[href^="#"]').forEach(link => link.addEventListener("click", e => {
  const target = $(link.getAttribute("href"));
  if (target) {
    // Native smooth scrolling is retained; this listener is intentionally non-blocking.
  }
}));
